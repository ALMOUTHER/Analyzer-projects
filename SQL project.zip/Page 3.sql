select Invoice.BillingCountry Country, count(*) Customers
from Customer
join Invoice
on Invoice.CustomerId = Customer.CustomerId
group by 1
order by Customers desc
limit 6;

