select A99.Artistname Artist_name, Sum(A99.UP) Total_sells
from (select Artist.Name Artistname, InvoiceLine.UnitPrice UP
from InvoiceLine
join Track
on InvoiceLine.TrackId = Track.TrackId
join Album
on Album.AlbumId = Track.AlbumId
join Artist
on Artist.ArtistId = Album.ArtistId
) A99
Group by 1
order by Total_sells desc
limit 4;