select  m3.Albumname, count(*) Quantity
from (select InvoiceLine.Quantity, Album.Title Albumname
from Track 
JOIN Album 
on Track.AlbumID = Album.AlbumId
join InvoiceLine
on InvoiceLine.TrackId = Track.TrackId
order by Quantity ) m3
group by 1
order by Count(*) desc
limit 5 ;
