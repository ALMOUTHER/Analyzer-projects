select M00.Media_name Media_Type , max(M00.AL)/1000000 MB
from(select Track.Bytes AL, MediaType.Name Media_name
From Track
join MediaType
on MediaType.MediaTypeId = Track.MediaTypeId ) M00
group by 1
ORDER by MB desc;